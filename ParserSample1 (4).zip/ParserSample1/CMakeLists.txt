cmake_minimum_required(VERSION 3.20)
project(ParserSample1 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

add_executable(${PROJECT_NAME}
    Main.cpp
    Lexer.cpp
    Lexer.hpp
    Parser.cpp
    Parser.hpp
)

if(MSVC)
  target_compile_options(${PROJECT_NAME} PRIVATE /W4)
else()
  target_compile_options(${PROJECT_NAME} PRIVATE -Wall -Wextra -Wpedantic)
endif()

# Tests: every file in examples/valid must parse, every file in examples/invalid must fail.
enable_testing()

file(GLOB VALID_EXAMPLES CONFIGURE_DEPENDS ${CMAKE_CURRENT_SOURCE_DIR}/examples/valid/*.txt)
foreach(example IN LISTS VALID_EXAMPLES)
  get_filename_component(name ${example} NAME_WE)
  add_test(NAME valid_${name} COMMAND ${PROJECT_NAME} ${example})
endforeach()

file(GLOB INVALID_EXAMPLES CONFIGURE_DEPENDS ${CMAKE_CURRENT_SOURCE_DIR}/examples/invalid/*.txt)
foreach(example IN LISTS INVALID_EXAMPLES)
  get_filename_component(name ${example} NAME_WE)
  add_test(NAME invalid_${name} COMMAND ${PROJECT_NAME} ${example})
  set_tests_properties(invalid_${name} PROPERTIES WILL_FAIL TRUE)
endforeach()
